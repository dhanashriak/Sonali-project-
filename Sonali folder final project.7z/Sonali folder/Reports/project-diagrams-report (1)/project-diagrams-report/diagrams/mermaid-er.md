

### Entities
- **Manufacturer**(id, name, contact, address)
- **Product**(id, sku*, name, category, unit, manufacturer_id→Manufacturer)
- **Purchase**(id, invoice_no, supplier_name, purchase_date, total_amount)
- **PurchaseItem**(id, purchase_id→Purchase, product_id→Product, quantity, unit_cost, batch_no, mfg_date, expiry_date)
- **Batch**(id, product_id→Product, purchase_id→Purchase, batch_no*, mfg_date, expiry_date, qty_received, qty_on_hand, unit_cost)
- **StockMovement**(id, batch_id→Batch, movement_type, quantity, reason, movement_date)
- **ExpiryAlert**(id, batch_id→Batch, alert_date, days_to_expiry, status, note)
- **LossRecord**(id, batch_id→Batch, expired_quantity, loss_amount, recorded_date, reason)
- **UserAccount**(id, username*, password_hash, role, email, enabled, created_at)

### ER (Mermaid)
```mermaid
erDiagram
  MANUFACTURERS ||--o{ PRODUCTS : has
  PRODUCTS ||--o{ BATCHES : has
  PURCHASES ||--o{ PURCHASE_ITEMS : contains
  PRODUCTS ||--o{ PURCHASE_ITEMS : item_for
  PURCHASES ||--o{ BATCHES : generates
  BATCHES ||--o{ STOCK_MOVEMENTS : logs
  BATCHES ||--o{ EXPIRY_ALERTS : triggers
  BATCHES ||--o{ LOSS_RECORDS : recorded

  MANUFACTURERS {
    bigint id PK
    string name UK
    string contact_email
    string phone
    text address
  }
  PRODUCTS {
    bigint id PK
    string sku UK
    string name
    string category
    string unit
    bigint manufacturer_id FK
  }
  PURCHASES {
    bigint id PK
    string invoice_no
    string supplier_name
    date purchase_date
    numeric total_amount
  }
  PURCHASE_ITEMS {
    bigint id PK
    bigint purchase_id FK
    bigint product_id FK
    int quantity
    numeric unit_cost
    string batch_no
    date mfg_date
    date expiry_date
  }
  BATCHES {
    bigint id PK
    bigint product_id FK
    bigint purchase_id FK
    string batch_no UK(product_id,batch_no)
    date mfg_date
    date expiry_date
    int qty_received
    int qty_on_hand
    numeric unit_cost
  }
  STOCK_MOVEMENTS {
    bigint id PK
    bigint batch_id FK
    string movement_type
    int quantity
    string reason
    timestamp movement_date
  }
  EXPIRY_ALERTS {
    bigint id PK
    bigint batch_id FK
    date alert_date
    int days_to_expiry
    string status
    string note
  }
  LOSS_RECORDS {
    bigint id PK
    bigint batch_id FK
    int expired_quantity
    numeric loss_amount
    timestamp recorded_date
    string reason
  }
  USERS {
    bigint id PK
    string username UK
    string password_hash
    string role
    string email
    boolean enabled
    timestamp created_at
  }
```

