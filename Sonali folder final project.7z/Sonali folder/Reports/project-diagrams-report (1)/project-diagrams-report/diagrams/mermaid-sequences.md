### Purchase → Batches
mermaid
sequenceDiagram
  participant UI as Purchases UI
  participant PC as PurchaseController
  participant PS as PurchaseService
  participant PR as PurchaseRepository
  participant ProdR as ProductRepository
  participant InvS as InventoryService
  participant BR as BatchRepository
  participant SMR as StockMovementRepository

  UI->>PC: POST /api/purchases (invoice, items[])
  PC->>PS: createPurchaseAndBatches(dto)
  loop For each item
    PS->>ProdR: findById(productId)
    ProdR-->>PS: Product
  end
  PS->>PR: save(Purchase+items)
  PR-->>PS: Purchase saved
  loop For each item
    PS->>InvS: createBatch(productId, batchNo, mfg, exp, qty, cost, purchase)
    InvS->>BR: save(Batch)
    BR-->>InvS: Batch saved
    InvS->>SMR: save(StockMovement IN)
  end
  PS-->>PC: Purchase with items & batches
  PC-->>UI: 200 OK


### Daily Expiry Scan
mermaid
sequenceDiagram
  participant SCH as Scheduler (01:00 IST)
  participant ES as ExpiryService
  participant BR as BatchRepository
  participant AR as ExpiryAlertRepository
  participant LR as LossRecordRepository
  participant SMR as StockMovementRepository

  SCH->>ES: generateAlerts()
  ES->>BR: findExpiringBetween(today, today+N)
  BR-->>ES: batches[]
  loop batches
    ES->>AR: save(PENDING alert)
  end

  SCH->>ES: processExpired()
  ES->>BR: findExpired(today)
  BR-->>ES: expired[]
  loop expired batches with qty_on_hand>0
    ES->>LR: save(LossRecord)
    ES->>SMR: save(StockMovement EXPIRED)
    ES->>BR: update qty_on_hand = 0
  end
