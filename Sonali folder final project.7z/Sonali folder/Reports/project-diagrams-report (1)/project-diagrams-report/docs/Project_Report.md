
# Product Expiration & Inventory System — Technical Report

**Stack:** Java 8 • Spring Boot 2.7 • Spring Data JPA • Spring Security • PostgreSQL • HTML5/JS • Thymeleaf

**Location/Timezone Assumption:** Asia/Kolkata (IST) — daily scheduler at 01:00 IST.

---

## 1. Problem Statement & Goals

Expired products cause health hazards and business losses. Manual stock-taking is error-prone for small/mid businesses. The system detects products that are **about to expire** or **expired**, notifies stakeholders, and computes loss. It includes inventory management, purchase-to-batch linkage, manufacturer & product catalog, alerting, and reporting.

### Objectives
1. Easy inventory management (Products, Batches, Stock Movements)
2. Handle purchase and manufacturer details with batch-level **expiry**
3. Maintain per-batch records for products
4. Record products and stock movements (IN/OUT/ADJUST/EXPIRED)
5. Detect **about-to-expire** and **expired** items
6. Calculate loss on expired products

### Significance
Reduces health risks and losses; enables actions like clearance sales and immediate consumption before expiry.

---

## 2. Architecture Overview

- **Client:** HTML5 pages (`index.html`, `products.html`, `purchases.html`) using Fetch API
- **Server:** Spring Boot (REST Controllers + Services + Scheduler)
- **Persistence:** Spring Data JPA → PostgreSQL
- **Security:** Spring Security (form login, role-based authorization)
- **Batch/Alerts:** Daily scheduler to generate alerts and process expired stock

### Component Diagram (Mermaid)
```mermaid
flowchart LR
  A[Browser UI
HTML5/JS] -- REST --> B[Spring MVC Controllers]
  B -- Service calls --> C[Services
Inventory/Expiry/Purchase/Product]
  C -- JPA --> D[(PostgreSQL DB)]
  C <-- Scheduler --> E[Spring Scheduler
Daily @ 01:00 IST]
  B <-- Security --> F[Spring Security
Form Login + Roles]
```

---

## 3. Domain Model (ER Diagram)

### Entities
- **Manufacturer**(id, name, contact, address)
- **Product**(id, sku*, name, category, unit, manufacturer_id→Manufacturer)
- **Purchase**(id, invoice_no, supplier_name, purchase_date, total_amount)
- **PurchaseItem**(id, purchase_id→Purchase, product_id→Product, quantity, unit_cost, batch_no, mfg_date, expiry_date)
- **Batch**(id, product_id→Product, purchase_id→Purchase, batch_no*, mfg_date, expiry_date, qty_received, qty_on_hand, unit_cost)
- **StockMovement**(id, batch_id→Batch, movement_type, quantity, reason, movement_date)
- **ExpiryAlert**(id, batch_id→Batch, alert_date, days_to_expiry, status, note)
- **LossRecord**(id, batch_id→Batch, expired_quantity, loss_amount, recorded_date, reason)
- **UserAccount**(id, username*, password_hash, role, email, enabled, created_at)

### ER (Mermaid)
```mermaid
erDiagram
  MANUFACTURERS ||--o{ PRODUCTS : has
  PRODUCTS ||--o{ BATCHES : has
  PURCHASES ||--o{ PURCHASE_ITEMS : contains
  PRODUCTS ||--o{ PURCHASE_ITEMS : item_for
  PURCHASES ||--o{ BATCHES : generates
  BATCHES ||--o{ STOCK_MOVEMENTS : logs
  BATCHES ||--o{ EXPIRY_ALERTS : triggers
  BATCHES ||--o{ LOSS_RECORDS : recorded

  MANUFACTURERS {
    bigint id PK
    string name UK
    string contact_email
    string phone
    text address
  }
  PRODUCTS {
    bigint id PK
    string sku UK
    string name
    string category
    string unit
    bigint manufacturer_id FK
  }
  PURCHASES {
    bigint id PK
    string invoice_no
    string supplier_name
    date purchase_date
    numeric total_amount
  }
  PURCHASE_ITEMS {
    bigint id PK
    bigint purchase_id FK
    bigint product_id FK
    int quantity
    numeric unit_cost
    string batch_no
    date mfg_date
    date expiry_date
  }
  BATCHES {
    bigint id PK
    bigint product_id FK
    bigint purchase_id FK
    string batch_no UK(product_id,batch_no)
    date mfg_date
    date expiry_date
    int qty_received
    int qty_on_hand
    numeric unit_cost
  }
  STOCK_MOVEMENTS {
    bigint id PK
    bigint batch_id FK
    string movement_type
    int quantity
    string reason
    timestamp movement_date
  }
  EXPIRY_ALERTS {
    bigint id PK
    bigint batch_id FK
    date alert_date
    int days_to_expiry
    string status
    string note
  }
  LOSS_RECORDS {
    bigint id PK
    bigint batch_id FK
    int expired_quantity
    numeric loss_amount
    timestamp recorded_date
    string reason
  }
  USERS {
    bigint id PK
    string username UK
    string password_hash
    string role
    string email
    boolean enabled
    timestamp created_at
  }
```

---

## 4. UML Class Diagram (key aggregates)
```mermaid
classDiagram
  class Manufacturer {+id:Long +name:String +contactEmail:String +phone:String +address:String}
  class Product {+id:Long +sku:String +name:String +category:String +unit:String +manufacturer:Manufacturer}
  class Purchase {+id:Long +invoiceNo:String +supplierName:String +purchaseDate:LocalDate +totalAmount:BigDecimal +items:List<PurchaseItem>}
  class PurchaseItem {+id:Long +purchase:Purchase +product:Product +quantity:int +unitCost:BigDecimal +batchNo:String +mfgDate:LocalDate +expiryDate:LocalDate}
  class Batch {+id:Long +product:Product +purchase:Purchase +batchNo:String +mfgDate:LocalDate +expiryDate:LocalDate +qtyReceived:int +qtyOnHand:int +unitCost:BigDecimal}
  class StockMovement {+id:Long +batch:Batch +movementType:String +quantity:int +reason:String +movementDate:LocalDateTime}
  class ExpiryAlert {+id:Long +batch:Batch +alertDate:LocalDate +daysToExpiry:int +status:String +note:String}
  class LossRecord {+id:Long +batch:Batch +expiredQuantity:int +lossAmount:BigDecimal +recordedDate:LocalDateTime +reason:String}
  class UserAccount {+id:Long +username:String +passwordHash:String +role:String +email:String +enabled:Boolean +createdAt:LocalDateTime}

  Manufacturer "1" --> "*" Product
  Product "1" --> "*" Batch
  Purchase "1" --> "*" PurchaseItem
  Product "1" --> "*" PurchaseItem
  Purchase "1" --> "*" Batch
  Batch "1" --> "*" StockMovement
  Batch "1" --> "*" ExpiryAlert
  Batch "1" --> "*" LossRecord
```

---

## 5. Use Case Diagram (Mermaid)
```mermaid
flowchart LR
  actorAdmin([Admin])
  actorManager([Manager])
  actorClerk([Clerk])

  subgraph System[Product Expiration System]
    UC1([Manage Products (CRUD)])
    UC2([Record Purchase & Create Batches])
    UC3([Daily Expiry Scan])
    UC4([Acknowledge Alerts])
    UC5([Reports: Loss & Expiring])
    UC6([Login/Logout])
  end

  actorAdmin -- access --> UC1
  actorAdmin -- access --> UC2
  actorAdmin -- access --> UC3
  actorAdmin -- access --> UC4
  actorAdmin -- access --> UC5
  actorAdmin -- access --> UC6

  actorManager -- access --> UC1
  actorManager -- access --> UC2
  actorManager -- access --> UC3
  actorManager -- access --> UC4
  actorManager -- access --> UC5
  actorManager -- access --> UC6

  actorClerk -- limited --> UC1
  actorClerk -- limited --> UC5
  actorClerk -- access --> UC6
```

---

## 6. Sequence Diagrams

### 6.1 Purchase → Batches creation
```mermaid
sequenceDiagram
  participant UI as Purchases UI
  participant PC as PurchaseController
  participant PS as PurchaseService
  participant PR as PurchaseRepository
  participant ProdR as ProductRepository
  participant InvS as InventoryService
  participant BR as BatchRepository
  participant SMR as StockMovementRepository

  UI->>PC: POST /api/purchases (invoice, items[])
  PC->>PS: createPurchaseAndBatches(dto)
  loop For each item
    PS->>ProdR: findById(productId)
    ProdR-->>PS: Product
  end
  PS->>PR: save(Purchase+items)
  PR-->>PS: Purchase saved
  loop For each item
    PS->>InvS: createBatch(productId, batchNo, mfg, exp, qty, cost, purchase)
    InvS->>BR: save(Batch)
    BR-->>InvS: Batch saved
    InvS->>SMR: save(StockMovement IN)
  end
  PS-->>PC: Purchase with items & batches
  PC-->>UI: 200 OK
```

### 6.2 Daily expiry scan & processing
```mermaid
sequenceDiagram
  participant SCH as Scheduler (01:00 IST)
  participant ES as ExpiryService
  participant BR as BatchRepository
  participant AR as ExpiryAlertRepository
  participant LR as LossRecordRepository
  participant SMR as StockMovementRepository

  SCH->>ES: generateAlerts()
  ES->>BR: findExpiringBetween(today, today+N)
  BR-->>ES: batches[]
  loop batches
    ES->>AR: save(PENDING alert)
  end

  SCH->>ES: processExpired()
  ES->>BR: findExpired(today)
  BR-->>ES: expired[]
  loop expired batches with qty_on_hand>0
    ES->>LR: save(LossRecord)
    ES->>SMR: save(StockMovement EXPIRED)
    ES->>BR: update qty_on_hand = 0
  end
```

### 6.3 Alert acknowledgement
```mermaid
sequenceDiagram
  participant UI as Dashboard
  participant AC as AlertController
  participant AR as ExpiryAlertRepository

  UI->>AC: POST /api/alerts/{id}/ack
  AC->>AR: findById(id)
  AR-->>AC: alert
  AC->>AR: save(status=ACKNOWLEDGED)
  AC-->>UI: 200 OK
```

### 6.4 Product CRUD
```mermaid
sequenceDiagram
  participant UI as Products UI
  participant PC as ProductController
  participant PS as ProductService
  participant PR as ProductRepository
  participant BR as BatchRepository

  UI->>PC: POST /api/products (create)
  PC->>PS: create(Product)
  PS->>PR: existsBySku(sku)?
  PR-->>PS: boolean
  PS->>PR: save(Product)
  PS-->>PC: Product
  PC-->>UI: 201 Created

  UI->>PC: DELETE /api/products/{id}
  PC->>PS: delete(id)
  PS->>BR: countByProductId(id)
  BR-->>PS: count
  alt count>0
    PS-->>PC: 400 Cannot delete (batches exist)
  else
    PS->>PR: delete(Product)
    PS-->>PC: 204 No Content
  end
```

---

## 7. Activity Diagram — Purchase flow
```mermaid
flowchart TD
  S([Start]) --> H[Enter purchase header]
  H --> I[Add items]
  I --> V{Validate items}
  V -- invalid --> I
  V -- valid --> C[Compute total]
  C --> P[Persist purchase+items]
  P --> B[Create batches for each item]
  B --> M[Create IN stock movements]
  M --> E([End])
```

---

## 8. Deployment Diagram (textual overview)
- **Web Browser** (Client) → HTTP(S) → **Spring Boot App** (Tomcat embedded)
- App connects to **PostgreSQL** over TCP (5432)
- (Optional) SMTP for email notifications
- Scheduler runs on the App node (cron-like via Spring)

```mermaid
flowchart LR
  Client[User Browser] -->|HTTPS| App[Spring Boot Service]
  App -->|JDBC| DB[(PostgreSQL)]
  App -.->|Scheduler| Job[Daily Scan]
```

---

## 9. Data Dictionary (summary)

| Table | Key Columns | Notes |
|---|---|---|
| **manufacturers** | `id PK`, `name UK` | Manufacturer catalog |
| **products** | `id PK`, `sku UK`, `manufacturer_id FK` | Product catalog |
| **purchases** | `id PK`, `invoice_no`, `purchase_date` | Purchase header |
| **purchase_items** | `id PK`, `purchase_id FK`, `product_id FK` | Items within purchase; carries batch metadata |
| **batches** | `id PK`, `product_id FK`, `purchase_id FK`, `batch_no unique per product` | Inventory unit with expiry |
| **stock_movements** | `id PK`, `batch_id FK`, `movement_type` | IN/OUT/ADJUST/EXPIRED audit |
| **expiry_alerts** | `id PK`, `batch_id FK`, `status` | PENDING/ACKNOWLEDGED/CLEARED |
| **loss_records** | `id PK`, `batch_id FK`, `loss_amount` | cost × qty_on_hand |
| **users** | `id PK`, `username UK` | Authentication & authorization |

---

## 10. API Surface (selected)
- `POST /api/purchases` → Create purchase & batches
- `GET /api/batches` / `GET /api/batches/expiring?days=N` / `GET /api/batches/expired`
- `POST /api/alerts/run` / `POST /api/alerts/{id}/ack` / `GET /api/alerts`
- `POST /api/products` / `PUT /api/products/{id}` / `DELETE /api/products/{id}` / `GET /api/products`
- `GET /api/report/expiring?days=N` / `GET /api/report/loss`

---

## 11. Non-functional Requirements
- **Performance:** Indexes on `batches.expiry_date`, `batches.product_id`, `products.sku`
- **Security:** Form login, role-based rules. Passwords stored as BCrypt hashes.
- **Reliability:** Idempotency for alerts (by date/type/batch if extended).
- **Scalability:** Stateless controllers; horizontal scaling feasible; DB connections pooled via HikariCP.

---

## 12. Risks & Mitigation
- **Incorrect expiry data** → Validation, defaults based on category; optional shelf-life policy
- **Large imports** → Batch inserts, CSV/Excel import pipeline
- **Deletion with history** → Safe delete rule; consider soft-delete/archival

---

## 13. Future Enhancements
- Supplier master
- Category-specific warning thresholds
- Email/SMS notifications
- Barcode scanning for faster stock operations
- Soft-delete / deactivation for products

---

## 14. Traceability Matrix (Objectives → Features)
- Inventory mgmt → Product/Batch/Movement modules
- Purchase details → Purchase & PurchaseItem
- Batch records → Batch tied to Purchase & Product
- Detect expiry → Scheduler + ExpiryService
- Loss calculation → processExpired() + LossRecord
- Decision support → Reports + Alerts

---

*End of Report*
