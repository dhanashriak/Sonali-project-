
package com.product.expiry.config;

import com.product.expiry.service.ExpiryService;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
public class ExpiryScheduler {
  private final ExpiryService expiryService;
  public ExpiryScheduler(ExpiryService expiryService) { this.expiryService = expiryService; }

  @Scheduled(cron = "0 0 1 * * *", zone = "Asia/Kolkata")
  public void runDailyChecks() {
    expiryService.generateAlerts();
    expiryService.processExpired();
  }
}
