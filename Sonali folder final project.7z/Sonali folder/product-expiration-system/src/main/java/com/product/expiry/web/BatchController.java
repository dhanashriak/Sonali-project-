
package com.product.expiry.web;

import com.product.expiry.domain.Batch;
import com.product.expiry.repo.BatchRepository;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/batches")
public class BatchController {
  private final BatchRepository batchRepo;

  public BatchController(BatchRepository batchRepo) {
    this.batchRepo = batchRepo;
  }

  @GetMapping
  public List<Batch> list() { return batchRepo.findAll(); }

  @GetMapping("/expired")
  public List<Batch> expired() {
    return batchRepo.findExpired(LocalDate.now());
  }

  @GetMapping("/expiring")
  public List<Batch> expiring(@RequestParam(defaultValue="30") int days) {
    LocalDate today = LocalDate.now();
    return batchRepo.findExpiringBetween(today, today.plusDays(days));
  }
}
