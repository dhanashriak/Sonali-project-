
package com.product.expiry.service;

import com.product.expiry.domain.Batch;
import com.product.expiry.domain.ExpiryAlert;
import com.product.expiry.domain.LossRecord;
import com.product.expiry.domain.StockMovement;
import com.product.expiry.repo.BatchRepository;
import com.product.expiry.repo.ExpiryAlertRepository;
import com.product.expiry.repo.LossRecordRepository;
import com.product.expiry.repo.StockMovementRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@Service
public class ExpiryService {
  private final BatchRepository batchRepo;
  private final ExpiryAlertRepository alertRepo;
  private final LossRecordRepository lossRepo;
  private final StockMovementRepository movementRepo;

  @Value("${expiry.warning.days:30}")
  private int warningDays;

  public ExpiryService(BatchRepository batchRepo, ExpiryAlertRepository alertRepo,
                       LossRecordRepository lossRepo, StockMovementRepository movementRepo) {
    this.batchRepo = batchRepo;
    this.alertRepo = alertRepo;
    this.lossRepo = lossRepo;
    this.movementRepo = movementRepo;
  }

  @Transactional
  public void generateAlerts() {
    LocalDate today = LocalDate.now();
    LocalDate thresholdDate = today.plusDays(warningDays);
    for (Batch b : batchRepo.findExpiringBetween(today, thresholdDate)) {
      int days = (int) ChronoUnit.DAYS.between(today, b.getExpiryDate());
      ExpiryAlert alert = new ExpiryAlert();
      alert.setBatch(b);
      alert.setAlertDate(today);
      alert.setDaysToExpiry(days);
      alert.setStatus("PENDING");
      alert.setNote("Batch " + b.getBatchNo() + " expiring in " + days + " day(s).");
      alertRepo.save(alert);
    }
  }

  @Transactional
  public void processExpired() {
    LocalDate today = LocalDate.now();
    for (Batch b : batchRepo.findExpired(today)) {
      int qty = b.getQtyOnHand();
      if (qty <= 0) continue;

      BigDecimal loss = b.getUnitCost().multiply(BigDecimal.valueOf(qty));
      LossRecord lr = new LossRecord();
      lr.setBatch(b);
      lr.setExpiredQuantity(qty);
      lr.setLossAmount(loss);
      lr.setReason("Expired on " + b.getExpiryDate());
      lossRepo.save(lr);

      StockMovement mv = new StockMovement();
      mv.setBatch(b);
      mv.setMovementType("EXPIRED");
      mv.setQuantity(qty);
      mv.setReason("System expiry");
      movementRepo.save(mv);

      b.setQtyOnHand(0);
      batchRepo.save(b);
    }
  }
}
