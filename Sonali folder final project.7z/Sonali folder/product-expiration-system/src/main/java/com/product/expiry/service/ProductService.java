
package com.product.expiry.service;

import com.product.expiry.domain.Product;
import com.product.expiry.repo.BatchRepository;
import com.product.expiry.repo.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ProductService {
  private final ProductRepository productRepo;
  private final BatchRepository batchRepo;

  public ProductService(ProductRepository productRepo, BatchRepository batchRepo) {
    this.productRepo = productRepo;
    this.batchRepo = batchRepo;
  }

  @Transactional(readOnly = true)
  public Product getOr404(Long id) {
    return productRepo.findById(id)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found: " + id));
  }

  @Transactional
  public Product create(Product p) {
    if (productRepo.existsBySku(p.getSku())) {
      throw new ResponseStatusException(HttpStatus.CONFLICT, "SKU already exists: " + p.getSku());
    }
    return productRepo.save(p);
  }

  @Transactional
  public Product update(Long id, Product updates) {
    Product existing = getOr404(id);
    if (!existing.getSku().equals(updates.getSku()) && productRepo.existsBySku(updates.getSku())) {
      throw new ResponseStatusException(HttpStatus.CONFLICT, "SKU already exists: " + updates.getSku());
    }
    existing.setSku(updates.getSku());
    existing.setName(updates.getName());
    existing.setCategory(updates.getCategory());
    existing.setUnit(updates.getUnit());
    return productRepo.save(existing);
  }

  @Transactional
  public void delete(Long id) {
    Product existing = getOr404(id);
    long batchCount = batchRepo.countByProductId(existing.getId());
    if (batchCount > 0) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
          "Cannot delete product with existing batches (" + batchCount + "). Consider deactivation/archival.");
    }
    productRepo.delete(existing);
  }
}
