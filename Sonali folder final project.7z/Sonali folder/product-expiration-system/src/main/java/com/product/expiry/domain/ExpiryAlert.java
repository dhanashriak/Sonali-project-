
package com.product.expiry.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@Entity
@Table(name = "expiry_alerts")
public class ExpiryAlert {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.EAGER, optional = false)
  @JoinColumn(name = "batch_id")
  private Batch batch;

  @Column(nullable = false)
  private LocalDate alertDate;

  @Column(nullable = false)
  private Integer daysToExpiry;

  @Column(nullable = false)
  private String status; // PENDING, ACKNOWLEDGED, CLEARED

  private String note;
}
