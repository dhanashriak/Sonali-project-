
package com.product.expiry.web;

import com.product.expiry.domain.Product;
import com.product.expiry.repo.ProductRepository;
import com.product.expiry.service.ProductService;
import com.product.expiry.web.dto.ProductDto;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@RestController
@RequestMapping("/api/products")
public class ProductController {
  private final ProductRepository repo;
  private final ProductService productService;

  public ProductController(ProductRepository repo, ProductService productService) {
    this.repo = repo;
    this.productService = productService;
  }

  @PostMapping
  public Product create(@Valid @RequestBody ProductDto dto) {
    Product p = new Product();
    p.setSku(dto.getSku());
    p.setName(dto.getName());
    p.setCategory(dto.getCategory());
    p.setUnit(dto.getUnit());
    return productService.create(p);
  }

  @GetMapping
  public List<Product> list() { return repo.findAll(); }

  @GetMapping("/{id}")
  public Product get(@PathVariable Long id) {
    return repo.findById(id)
        .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Product not found: " + id));
  }

  @PutMapping("/{id}")
  public Product update(@PathVariable Long id, @Valid @RequestBody ProductDto dto) {
    Product updates = new Product();
    updates.setSku(dto.getSku());
    updates.setName(dto.getName());
    updates.setCategory(dto.getCategory());
    updates.setUnit(dto.getUnit());
    return productService.update(id, updates);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable Long id) {
    productService.delete(id);
  }

  @GetMapping("/exists")
  public boolean existsBySku(@RequestParam String sku) {
    return repo.existsBySku(sku);
  }
}
