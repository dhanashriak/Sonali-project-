
package com.product.expiry.service;

import com.product.expiry.domain.Batch;
import com.product.expiry.domain.Product;
import com.product.expiry.domain.Purchase;
import com.product.expiry.domain.StockMovement;
import com.product.expiry.repo.BatchRepository;
import com.product.expiry.repo.StockMovementRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;

@Service
public class InventoryService {
  private final BatchRepository batchRepo;
  private final StockMovementRepository movementRepo;

  public InventoryService(BatchRepository batchRepo, StockMovementRepository movementRepo) {
    this.batchRepo = batchRepo;
    this.movementRepo = movementRepo;
  }

  @Transactional
  public Batch createBatch(Long productId, String batchNo, LocalDate mfgDate, LocalDate expiryDate,
                           int qtyReceived, BigDecimal unitCost, Purchase purchase) {
    Batch b = new Batch();
    Product p = new Product(); p.setId(productId);
    b.setProduct(p);
    b.setBatchNo(batchNo);
    b.setMfgDate(mfgDate);
    b.setExpiryDate(expiryDate);
    b.setQtyReceived(qtyReceived);
    b.setQtyOnHand(qtyReceived);
    b.setUnitCost(unitCost);
    b.setPurchase(purchase);
    Batch saved = batchRepo.save(b);

    StockMovement mv = new StockMovement();
    mv.setBatch(saved);
    mv.setMovementType("IN");
    mv.setQuantity(qtyReceived);
    mv.setReason("Initial receipt");
    movementRepo.save(mv);

    return saved;
  }
}
