
package com.product.expiry.web.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class ProductDto {
  @NotBlank @Size(max = 64)
  private String sku;

  @NotBlank @Size(max = 200)
  private String name;

  @Size(max = 100)
  private String category;

  @NotBlank @Size(max = 30)
  private String unit; // pcs/kg/ltr

  public String getSku() { return sku; }
  public void setSku(String sku) { this.sku = sku; }
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  public String getCategory() { return category; }
  public void setCategory(String category) { this.category = category; }
  public String getUnit() { return unit; }
  public void setUnit(String unit) { this.unit = unit; }
}
