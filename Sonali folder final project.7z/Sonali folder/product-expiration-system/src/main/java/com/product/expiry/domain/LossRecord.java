
package com.product.expiry.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@Entity
@Table(name = "loss_records")
public class LossRecord {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "batch_id")
  private Batch batch;

  @Column(nullable = false)
  private Integer expiredQuantity;

  @Column(nullable = false)
  private BigDecimal lossAmount;

  @Column(nullable = false)
  private LocalDateTime recordedDate = LocalDateTime.now();

  private String reason;
}
