
package com.product.expiry.repo;

import com.product.expiry.domain.ExpiryAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ExpiryAlertRepository extends JpaRepository<ExpiryAlert, Long> {
  List<ExpiryAlert> findByStatus(String status);
}
