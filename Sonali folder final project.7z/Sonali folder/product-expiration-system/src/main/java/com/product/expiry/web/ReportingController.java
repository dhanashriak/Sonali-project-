
package com.product.expiry.web;

import com.product.expiry.domain.Batch;
import com.product.expiry.domain.LossRecord;
import com.product.expiry.repo.BatchRepository;
import com.product.expiry.repo.LossRecordRepository;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/report")
public class ReportingController {
  private final LossRecordRepository lossRepo;
  private final BatchRepository batchRepo;

  public ReportingController(LossRecordRepository lossRepo, BatchRepository batchRepo) {
    this.lossRepo = lossRepo; this.batchRepo = batchRepo;
  }

  @GetMapping("/loss")
  public List<LossRecord> loss() { return lossRepo.findAll(); }

  @GetMapping("/expiring")
  public List<Batch> expiring(@RequestParam int days) {
    LocalDate today = LocalDate.now();
    return batchRepo.findExpiringBetween(today, today.plusDays(days));
  }
}
