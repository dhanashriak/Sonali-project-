
package com.product.expiry.security;

import com.product.expiry.domain.UserAccount;
import com.product.expiry.repo.UserAccountRepository;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

@Service
public class JpaUserDetailsService implements UserDetailsService {
  private final UserAccountRepository repo;
  public JpaUserDetailsService(UserAccountRepository repo) { this.repo = repo; }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    UserAccount ua = repo.findByUsername(username)
        .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

    return User.withUsername(ua.getUsername())
        .password(ua.getPasswordHash())
        .roles(ua.getRole().replace("ROLE_", ""))
        .disabled(Boolean.FALSE.equals(ua.getEnabled()))
        .build();
  }
}
