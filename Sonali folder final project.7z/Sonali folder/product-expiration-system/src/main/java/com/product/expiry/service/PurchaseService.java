
package com.product.expiry.service;


import com.product.expiry.domain.Product;
import com.product.expiry.domain.Purchase;
import com.product.expiry.domain.PurchaseItem;
import com.product.expiry.repo.ProductRepository;
import com.product.expiry.repo.PurchaseItemRepository;
import com.product.expiry.repo.PurchaseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class PurchaseService {
  private final PurchaseRepository purchaseRepo;
  private final PurchaseItemRepository itemRepo;
  private final ProductRepository productRepo;
  private final InventoryService inventoryService;

  public PurchaseService(PurchaseRepository purchaseRepo, PurchaseItemRepository itemRepo,
                         ProductRepository productRepo, InventoryService inventoryService) {
    this.purchaseRepo = purchaseRepo;
    this.itemRepo = itemRepo;
    this.productRepo = productRepo;
    this.inventoryService = inventoryService;
  }

  @Transactional
  public Purchase createPurchaseAndBatches(String invoiceNo, String supplierName, LocalDate purchaseDate,
                                           List<PurchaseItemPayload> items) {
    if (items == null || items.isEmpty()) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Purchase must have at least one item");
    }

    Purchase purchase = new Purchase();
    purchase.setInvoiceNo(invoiceNo);
    purchase.setSupplierName(supplierName);
    purchase.setPurchaseDate(purchaseDate);

    BigDecimal total = BigDecimal.ZERO;
    List<PurchaseItem> itemEntities = new ArrayList<>();

    int idx = 1;
    for (PurchaseItemPayload payload : items) {
      Product product = productRepo.findById(payload.getProductId())
          .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found: " + payload.getProductId()));

      if (payload.getQuantity() == null || payload.getQuantity() <= 0) {
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid quantity for product: " + payload.getProductId());
      }
      if (payload.getUnitCost() == null || payload.getUnitCost().compareTo(BigDecimal.ZERO) < 0) {
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid unit cost for product: " + payload.getProductId());
      }

      PurchaseItem pi = new PurchaseItem();
      pi.setPurchase(purchase);
      pi.setProduct(product);
      pi.setQuantity(payload.getQuantity());
      pi.setUnitCost(payload.getUnitCost());
      pi.setBatchNo(payload.getBatchNo() != null ? payload.getBatchNo() : generateBatchCode(invoiceNo, product.getSku(), idx));
      pi.setMfgDate(payload.getMfgDate());
      pi.setExpiryDate(payload.getExpiryDate());
      itemEntities.add(pi);

      total = total.add(payload.getUnitCost().multiply(BigDecimal.valueOf(payload.getQuantity())));
      idx++;
    }

    purchase.setTotalAmount(total);
    purchase.setItems(itemEntities);
    Purchase saved = purchaseRepo.save(purchase);

    // Create batches for each item
    for (PurchaseItem pi : saved.getItems()) {
      inventoryService.createBatch(
          pi.getProduct().getId(),
          pi.getBatchNo(),
          pi.getMfgDate(),
          pi.getExpiryDate(),
          pi.getQuantity(),
          pi.getUnitCost(),
          saved
      );
    }

    return saved;
  }

  private String generateBatchCode(String invoiceNo, String sku, int idx) {
    return (sku != null ? sku : "SKU") + "-" + (invoiceNo != null ? invoiceNo : "INV") + "-" + idx;
  }

  // Payload DTO used internally by service
  public static class PurchaseItemPayload {
    private Long productId;
    private Integer quantity;
    private BigDecimal unitCost;
    private String batchNo;
    private LocalDate mfgDate;
    private LocalDate expiryDate;

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public BigDecimal getUnitCost() { return unitCost; }
    public void setUnitCost(BigDecimal unitCost) { this.unitCost = unitCost; }
    public String getBatchNo() { return batchNo; }
    public void setBatchNo(String batchNo) { this.batchNo = batchNo; }
    public LocalDate getMfgDate() { return mfgDate; }
    public void setMfgDate(LocalDate mfgDate) { this.mfgDate = mfgDate; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }
  }
}
