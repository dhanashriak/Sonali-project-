
package com.product.expiry.web;

import com.product.expiry.domain.Purchase;
import com.product.expiry.service.PurchaseService;
import com.product.expiry.web.dto.PurchaseDto;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/purchases")
public class PurchaseController {
    private final PurchaseService purchaseService;

    public PurchaseController(PurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }

    @PostMapping
    public Purchase create(@Valid @RequestBody PurchaseDto dto) {
        return purchaseService.createPurchaseAndBatches(
                dto.getInvoiceNo(),
                dto.getSupplierName(),
                dto.getPurchaseDate(),
                dto.getItems().stream().map(item -> {
                    PurchaseService.PurchaseItemPayload p = new PurchaseService.PurchaseItemPayload();
                    p.setProductId(item.getProductId());
                    p.setQuantity(item.getQuantity());
                    p.setUnitCost(item.getUnitCost());
                    p.setBatchNo(item.getBatchNo());
                    p.setMfgDate(item.getMfgDate());
                    p.setExpiryDate(item.getExpiryDate());
                    return p;
                }).collect(Collectors.toList())
        );
    }
}
