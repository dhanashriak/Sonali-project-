
package com.product.expiry.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import javax.validation.constraints.Min;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@Entity
@Table(name = "batches", uniqueConstraints = @UniqueConstraint(columnNames = {"product_id", "batch_no"}))
public class Batch {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.EAGER, optional = false)
  @JoinColumn(name = "product_id")
  private Product product;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "purchase_id")
  private Purchase purchase;

  @Column(name = "batch_no", nullable = false)
  private String batchNo;

  private LocalDate mfgDate;

  @Column(name = "expiry_date")
  private LocalDate expiryDate;

  @Min(0)
  @Column(name = "qty_received", nullable = false)
  private Integer qtyReceived;

  @Min(0)
  @Column(name = "qty_on_hand", nullable = false)
  private Integer qtyOnHand;

  @Column(name = "unit_cost", nullable = false)
  private BigDecimal unitCost;
}
