package com.product.expiry.config;


// @Configuration class

import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.datatype.hibernate5.Hibernate5Module;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonHibernateConfig {

    @Bean
    public Module hibernateModule() {
        Hibernate5Module module = new Hibernate5Module();
        // Choose one behavior:
        // 1) Do NOT force-load lazy properties (they'll be omitted):
        // module.disable(Hibernate5Module.Feature.FORCE_LAZY_LOADING);

        // 2) Or DO force-load lazy properties if accessed during serialization:
        // module.enable(Hibernate5Module.Feature.FORCE_LAZY_LOADING);

        // 3) Optional: treat transient as nulls, etc.
        return module;
    }
}
