
package com.product.expiry.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.http.HttpMethod;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfig {
  @Bean
  public PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }

  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http
            .csrf(csrf -> csrf.ignoringAntMatchers("/api/**"))
            .authorizeRequests(auth -> auth
                    .antMatchers("/login", "/logout-success", "/css/**", "/js/**", "/images/**", "/", "/index.html", "/products.html", "/purchases.html").permitAll()
                    .antMatchers(HttpMethod.GET, "/api/products/**").hasAnyRole("ADMIN","MANAGER","CLERK")
                    .antMatchers(HttpMethod.POST, "/api/products").hasAnyRole("ADMIN","MANAGER")
                    .antMatchers(HttpMethod.PUT, "/api/products/**").hasAnyRole("ADMIN","MANAGER")
                    .antMatchers(HttpMethod.DELETE, "/api/products/**").hasRole("ADMIN")
                    .antMatchers("/api/purchases/**").hasAnyRole("ADMIN","MANAGER")
                    .antMatchers("/api/**").hasAnyRole("ADMIN","MANAGER","CLERK")
                    .antMatchers("/", "/index.html", "/products.html","/purchases.html").authenticated()
                    .anyRequest().authenticated()
            )
            .formLogin(form -> form
                    .loginPage("/login")
                    .loginProcessingUrl("/login")
                    .defaultSuccessUrl("/", true)
                    .failureUrl("/login?error=true")
                    .permitAll()
            )

            .logout(logout -> logout
                    .logoutRequestMatcher(new AntPathRequestMatcher("/logout", "GET"))
                    .logoutSuccessUrl("/logout-success")
                    .invalidateHttpSession(true)
                    .deleteCookies("JSESSIONID")
                    .permitAll()
            )

            .rememberMe(remember -> remember
                    .key("remember-me-secret")
                    .tokenValiditySeconds(1209600)
            )
            .httpBasic(Customizer.withDefaults());

    return http.build();
  }
}
