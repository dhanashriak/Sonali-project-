
package com.product.expiry.repo;

import com.product.expiry.domain.Batch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface BatchRepository extends JpaRepository<Batch, Long> {
  @Query("select b from Batch b where b.expiryDate >= :from and b.expiryDate <= :to and b.qtyOnHand > 0")
  List<Batch> findExpiringBetween(@Param("from") LocalDate from, @Param("to") LocalDate to);

  @Query("select b from Batch b where b.expiryDate < :today and b.qtyOnHand > 0")
  List<Batch> findExpired(@Param("today") LocalDate today);

  @Query("select count(b) from Batch b where b.product.id = :productId")
  long countByProductId(@Param("productId") Long productId);
}
