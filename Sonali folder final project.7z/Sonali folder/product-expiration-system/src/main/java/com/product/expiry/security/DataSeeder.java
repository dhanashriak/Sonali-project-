
package com.product.expiry.security;

import com.product.expiry.domain.UserAccount;
import com.product.expiry.repo.UserAccountRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataSeeder {
  @Bean
  CommandLineRunner initUsers(UserAccountRepository repo, PasswordEncoder encoder) {
    return args -> {
      if (!repo.findByUsername("admin").isPresent()) {
        UserAccount admin = new UserAccount();
        admin.setUsername("admin");
        admin.setPasswordHash(encoder.encode("admin123"));
        admin.setRole("ROLE_ADMIN");
        admin.setEmail("admin@example.com");
        admin.setEnabled(true);
        repo.save(admin);
        //System.out.println("Seeded default admin user: admin / admin123");
      }
    };
  }
}
