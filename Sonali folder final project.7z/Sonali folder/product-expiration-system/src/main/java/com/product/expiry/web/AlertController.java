
package com.product.expiry.web;

import com.product.expiry.domain.ExpiryAlert;
import com.product.expiry.repo.ExpiryAlertRepository;
import com.product.expiry.service.ExpiryService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@RestController
@RequestMapping("/api/alerts")
public class AlertController {
  private final ExpiryAlertRepository alertRepo;
  private final ExpiryService expiryService;

  public AlertController(ExpiryAlertRepository alertRepo, ExpiryService expiryService) {
    this.alertRepo = alertRepo; this.expiryService = expiryService;
  }

  @GetMapping
  public List<ExpiryAlert> list() { return alertRepo.findAll(); }

  @PostMapping("/run")
  public void runNow() { expiryService.generateAlerts(); }

  @PostMapping("/{id}/ack")
  public void acknowledge(@PathVariable Long id) {
    ExpiryAlert a = alertRepo.findById(id)
        .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Alert not found: " + id));
    a.setStatus("ACKNOWLEDGED");
    alertRepo.save(a);
  }
}
