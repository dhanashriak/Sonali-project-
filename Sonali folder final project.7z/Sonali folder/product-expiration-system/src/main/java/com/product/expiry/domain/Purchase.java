
package com.product.expiry.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
@Table(name = "purchases")
public class Purchase {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(nullable = false)
  private String invoiceNo;
  private String supplierName;
  @Column(nullable = false)
  private LocalDate purchaseDate;
  private BigDecimal totalAmount;

  @OneToMany(mappedBy = "purchase", cascade = CascadeType.ALL, orphanRemoval = true)
  private List<PurchaseItem> items = new ArrayList<>();
}
