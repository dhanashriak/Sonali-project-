
package com.product.expiry.repo;

import com.product.expiry.domain.LossRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LossRecordRepository extends JpaRepository<LossRecord, Long> {}
