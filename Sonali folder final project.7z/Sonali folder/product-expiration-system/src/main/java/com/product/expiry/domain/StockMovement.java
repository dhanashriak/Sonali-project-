
package com.product.expiry.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@Entity
@Table(name = "stock_movements")
public class StockMovement {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "batch_id")
  private Batch batch;

  @Column(nullable = false)
  private String movementType; // IN, OUT, ADJUST, EXPIRED

  @Column(nullable = false)
  private Integer quantity;

  private String reason;

  @Column(nullable = false)
  private LocalDateTime movementDate = LocalDateTime.now();
}
