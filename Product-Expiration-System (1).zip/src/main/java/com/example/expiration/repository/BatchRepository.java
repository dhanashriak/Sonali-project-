package com.example.expiration.repository;

import com.example.expiration.entity.Batch;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface BatchRepository extends JpaRepository<Batch, Long> {
    List<Batch> findByExpiryDateBefore(LocalDate date);
}
