package com.example.expiration.controller;

import com.example.expiration.service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class BatchController {

    @Autowired
    private BatchService service;

    @GetMapping("/expired")
    public String expired(Model model) {
        model.addAttribute("expired", service.getExpiredProducts());
        return "expired";
    }
}
