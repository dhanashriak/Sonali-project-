package com.example.expiration.service;

import com.example.expiration.entity.Batch;
import com.example.expiration.repository.BatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class BatchService {

    @Autowired
    private BatchRepository repository;

    public List<Batch> getExpiredProducts() {
        return repository.findByExpiryDateBefore(LocalDate.now());
    }
}
